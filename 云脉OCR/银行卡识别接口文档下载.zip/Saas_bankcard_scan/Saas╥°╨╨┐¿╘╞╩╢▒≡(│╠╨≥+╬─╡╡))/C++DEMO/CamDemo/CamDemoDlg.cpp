// CamDemoDlg.cpp : ʵ���ļ�
//

#include "stdafx.h"
#include "CamDemo.h"
#include "CamDemoDlg.h"
#include "md5.h"
#include "httpclient.h"
#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// ����Ӧ�ó��򡰹��ڡ��˵���� CAboutDlg �Ի���

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// �Ի�������
	enum { IDD = IDD_ABOUTBOX };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

// ʵ��
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// CCamDemoDlg �Ի���




CCamDemoDlg::CCamDemoDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCamDemoDlg::IDD, pParent)
	, m_text(_T(""))
{
	m_hIcon		= AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	m_PathName	= _T("");
	m_api		= _T("http://www.yunmaiocr.com/SrvXMLAPI");
	m_t 		= _T("PC");
	m_key 		= _T("");
	m_action 	= _T("bankcard.scan");
	m_time 		= _T("");
	m_loginid 	= _T("�û���");
	m_loginpwd 	= _T("����");
	
}

void CCamDemoDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_TEXT, m_text);
}

BEGIN_MESSAGE_MAP(CCamDemoDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_OPENPIC, &CCamDemoDlg::OnBnClickedOpenpic)
END_MESSAGE_MAP()


// CCamDemoDlg ��Ϣ��������

BOOL CCamDemoDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// ��������...���˵������ӵ�ϵͳ�˵��С�

	// IDM_ABOUTBOX ������ϵͳ���Χ�ڡ�
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// ���ô˶Ի����ͼ�ꡣ��Ӧ�ó��������ڲ��ǶԻ���ʱ����ܽ��Զ�
	//  ִ�д˲���
	SetIcon(m_hIcon, TRUE);			// ���ô�ͼ��
	SetIcon(m_hIcon, FALSE);		// ����Сͼ��

	// TODO: �ڴ����Ӷ���ĳ�ʼ������

	return TRUE;  // ���ǽ��������õ��ؼ������򷵻� TRUE
}

void CCamDemoDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// �����Ի���������С����ť������Ҫ����Ĵ���
//  �����Ƹ�ͼ�ꡣ����ʹ���ĵ�/��ͼģ�͵� MFC Ӧ�ó���
//  �⽫�ɿ���Զ���ɡ�

void CCamDemoDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // ���ڻ��Ƶ��豸������

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// ʹͼ���ڹ��������о���
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// ����ͼ��
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

//���û��϶���С������ʱϵͳ���ô˺���ȡ�ù����ʾ��
//
HCURSOR CCamDemoDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}


void CCamDemoDlg::OnBnClickedOpenpic()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CFileDialog m_dlg(TRUE,NULL,NULL,OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT|OFN_ALLOWMULTISELECT,
		"jpgͼƬ(*.jpg)|*.jpg|bmpͼƬ(*.bmp)|*.bmp|tifͼƬ(*.tiff)|*.tiff|pngͼƬ(*.png)|*.png",this);

	if (m_dlg.DoModal()==IDOK)
	{
		m_PathName = m_dlg.GetPathName();
	}

	CWnd* pWnd;
	pWnd=GetDlgItem(IDC_PICTURE);
	CDC* pDC=pWnd->GetDC();
	HDC hDC = pDC->m_hDC;
	CImage image;
	CRect rect_frame;
	pWnd->GetClientRect(&rect_frame);
	image.Load(m_PathName);

	::SetStretchBltMode(hDC,HALFTONE);
	::SetBrushOrgEx(hDC,0,0,NULL);

	image.Draw(hDC,rect_frame);
	ReleaseDC(pDC);//�ͷ�picture�ؼ���DC

	PostImage(m_PathName);
}

void CCamDemoDlg::PostImage(CString filepath)
{
	
	m_time = getmilliSeconds();
	m_key  = getGuid();
	CString md5buf = m_action + m_loginid + m_key + m_time + m_loginpwd;
	CMD5	iMD5;
	CString verifystr;
	iMD5.GenerateMD5((unsigned char *)(md5buf.GetBuffer()), strlen(md5buf.GetBuffer()));
	verifystr = iMD5.ToCString();
	verifystr.MakeUpper();
	
	CString password;
	iMD5.GenerateMD5((unsigned char *)(m_loginpwd.GetBuffer()), strlen(m_loginpwd.GetBuffer()));
	password = iMD5.ToCString();
	password.MakeUpper();
	CString filename = getGuid() + _T(".jpg");
	FILE *fp = fopen(filepath, "rb");
	fseek(fp, 0, SEEK_END);
	long lsize = ftell(fp);
	fseek(fp, 0, SEEK_SET);
	char *buf = new char[lsize + 1];
	int n = fread(buf, 1, lsize, fp);
	if (n < lsize)
	{
		MessageBox(_T("��ȡͼƬ������"));
		return;
	}
	

	CString poststrhead = _T("<action>") + m_action + _T("</action><client>") + m_loginid + _T("</client><system>") 
		+ m_t + _T("</system><password>") + password +_T("</password><key>") + m_key + _T("</key><time>") + m_time 
		+ _T("</time><verify>") + verifystr	+ _T("</verify><file>");

	int headlen = poststrhead.GetLength();
	CString poststrend  = _T("</file><etx>jpg</etx>");
	int endlen	= poststrend.GetLength();
	int nstrlen  = headlen + lsize + endlen; 
	char *ptrpost = new char [nstrlen + 1];
	memcpy(ptrpost, poststrhead.GetBuffer(), headlen);
	memcpy(ptrpost + headlen, buf, lsize);
	memcpy(ptrpost + headlen + lsize, poststrend, endlen);
	delete [] buf;
	fclose(fp);
	string resultstr;
	CHttpClient httpclient;
	httpclient.HttpPost( m_api.GetBuffer(), ptrpost, nstrlen, resultstr);
	delete [] ptrpost;
	int position = 0;
	if ((position = resultstr.find("<data>")) != string::npos)
	{
		if (position != 0)
		{
			resultstr.insert(position+6,"\r\n", 2);
			position = 0;
		}	
	}
	while ((position = resultstr.find_first_of('/',position)) != string::npos)
	{
		if ((position = resultstr.find_first_of('>',position+1)) != string::npos)
		{
			resultstr.insert(position+1,"\r\n", 2);
			position+=3;
		}
	}

	m_text.Format(_T("%s"), resultstr.c_str());
	UpdateData(FALSE);
}

CString CCamDemoDlg::getmilliSeconds()
{
	long long time_last;    
	time_last = time(NULL);     //������  
	struct timeb t1;    
	ftime(&t1);   
	CString strTime;  
	strTime.Format(_T("%lld"), t1.time * 1000 + t1.millitm);  //�ܺ�����   
	return strTime;
}

CString CCamDemoDlg::getGuid()
{
	GUID		m_guid; 
	CString		strGUID;   
	if (S_OK ==::CoCreateGuid(&m_guid))   
	{         
		strGUID.Format(_T("%08X-%04X-%04x-%02X%02X-%02X%02X%02X%02X%02X%02X"),
			m_guid.Data1,  m_guid.Data2,   m_guid.Data3 ,
			m_guid.Data4[0],   m_guid.Data4[1],
			m_guid.Data4[2],   m_guid.Data4[3],
			m_guid.Data4[4],   m_guid.Data4[5],
			m_guid.Data4[6],   m_guid.Data4[7]);   
	}   
	return strGUID;
}

