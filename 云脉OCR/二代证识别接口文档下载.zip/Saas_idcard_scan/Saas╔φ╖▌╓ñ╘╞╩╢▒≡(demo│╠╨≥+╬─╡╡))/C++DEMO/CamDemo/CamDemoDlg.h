// CamDemoDlg.h : ͷ�ļ�
//

#pragma once
#include "afxwin.h"
#include <atlimage.h>
#include <time.h>
#include <sys/timeb.h> 
#include <CString>
// CCamDemoDlg �Ի���
class CCamDemoDlg : public CDialog
{
// ����
public:
	CCamDemoDlg(CWnd* pParent = NULL);	// ��׼���캯��

// �Ի�������
	enum { IDD = IDD_CAMDEMO_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV ֧��


// ʵ��
protected:
	HICON m_hIcon;

	// ���ɵ���Ϣӳ�亯��
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedOpenpic();
private:
	CString m_PathName;
	CString m_api;
	CString m_rand;
	CString m_t;
	CString m_key;
	CString m_action;
	CString m_time;
	CString m_loginid;
	CString m_loginpwd;
	CString m_ocrLang;
	CString m_keyLang;
private:
	void PostImage(CString filepath);
	CString getmilliSeconds();
	CString getGuid();
private:
	CString m_text;
};
