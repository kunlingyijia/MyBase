//
//  PublicTF.h
//  京东购物车
//
//  Created by 席亚坤 on 16/11/24.
//  Copyright © 2016年 席亚坤. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PublicTF : UITextField
@property (nonatomic, strong) NSIndexPath  *indexPathBtn ;


@end
