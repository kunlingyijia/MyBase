//
//  ShopEditViewController.h
//  京东购物车
//
//  Created by 席亚坤 on 16/12/21.
//  Copyright © 2016年 席亚坤. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ShopEditViewController : UIViewController
///属性传值
@property (nonatomic,copy)NSMutableArray * MaindataArray;



@end
