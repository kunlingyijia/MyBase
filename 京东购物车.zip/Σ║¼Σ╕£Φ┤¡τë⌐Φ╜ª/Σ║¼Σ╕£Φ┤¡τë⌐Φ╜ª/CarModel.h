//
//  CarModel.h
//  京东购物车
//
//  Created by 席亚坤 on 16/12/21.
//  Copyright © 2016年 席亚坤. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CarModel : NSObject
///数量
@property (nonatomic, strong) NSString  *shu;
///选择状态
@property (nonatomic, strong) NSString  *chose;
///价格
@property (nonatomic, strong) NSString  * price ;



@end
