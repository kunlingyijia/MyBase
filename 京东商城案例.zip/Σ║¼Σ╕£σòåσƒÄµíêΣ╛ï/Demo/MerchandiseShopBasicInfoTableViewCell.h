//
//  MerchandiseShopInfoTableViewCell.h
//  Demo
//
//  Created by 张德雄 on 16/6/4.
//  Copyright © 2016年 GroupFly. All rights reserved.
//

#import <UIKit/UIKit.h>

extern NSString *const kMerchandiseShopBasicInfoTableViewCellIdentifier;

typedef void(^MerchandiseShopBasicInfoBlock)(NSInteger index);

@interface MerchandiseShopBasicInfoTableViewCell : UITableViewCell

@property (copy, nonatomic) MerchandiseShopBasicInfoBlock block;

@end
