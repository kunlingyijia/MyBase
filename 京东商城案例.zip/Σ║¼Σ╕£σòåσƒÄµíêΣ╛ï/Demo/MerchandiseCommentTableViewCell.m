//
//  MerchandiseCommentTableViewCell.m
//  Demo
//
//  Created by 张德雄 on 16/6/4.
//  Copyright © 2016年 GroupFly. All rights reserved.
//

#import "MerchandiseCommentTableViewCell.h"

NSString *const kMerchandiseCommentTableViewCellIdentifier = @"MerchandiseCommentTableViewCell";

@interface MerchandiseCommentTableViewCell ()

@end

@implementation MerchandiseCommentTableViewCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
