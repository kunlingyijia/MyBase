//
//  TableViewCell.h
//  百分比圆
//
//  Created by 席亚坤 on 16/12/30.
//  Copyright © 2016年 席亚坤. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PercentageRoudView.h"

@interface TableViewCell : UITableViewCell
///
@property (nonatomic, strong) PercentageRoudView  *roudView ;


@end
