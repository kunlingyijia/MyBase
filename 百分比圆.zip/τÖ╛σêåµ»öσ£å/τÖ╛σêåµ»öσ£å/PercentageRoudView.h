//
//  PercentageRoudView.h
//  百分比圆
//
//  Created by 席亚坤 on 16/12/1.
//  Copyright © 2016年 席亚坤. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PercentageRoudView : UIView
- (instancetype)initWithFrame:(CGRect)frame createPercentCircleWidth:(NSInteger)circleWidth ColorArray:(NSMutableArray *)colorArray PercentArray:(NSMutableArray *)percentArray percentText:(NSString*)Textstr
;
@end
