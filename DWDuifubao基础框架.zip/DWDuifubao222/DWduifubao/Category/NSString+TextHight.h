//
//  NSString+TextHight.h
//  
//
//  Created by kkk on 16/5/3.
//
//

#import <Foundation/Foundation.h>

@interface NSString (TextHight)

+ (CGFloat)getTextHight:(NSString *)text size:(NSInteger)size;



@end
