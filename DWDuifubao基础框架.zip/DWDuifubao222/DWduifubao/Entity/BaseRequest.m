//
//  BaseRequest.m
//  BianMin
//
//  Created by kkk on 16/5/26.
//  Copyright © 2016年 bianming. All rights reserved.
//

#import "BaseRequest.h"

@implementation BaseRequest

@end
