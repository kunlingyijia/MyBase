//
//  CityModel.m
//  AdressSelected
//
//  Created by kkk on 16/7/25.
//  Copyright © 2016年 bianming. All rights reserved.
//

#import "CityModel.h"

@implementation CityModel
@end
