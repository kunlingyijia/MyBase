//
//  RequestVerifyCode.h
//  DWduifubao
//
//  Created by kkk on 16/9/14.
//  Copyright © 2016年 bianming. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface RequestVerifyCode : NSObject

@property (nonatomic, assign) NSInteger type;
@property (nonatomic, copy) NSString *mobile;
@end
