//
//  RequestFeedback.h
//  DWduifubao
//
//  Created by 月美 刘 on 16/9/21.
//  Copyright © 2016年 bianming. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface RequestFeedback : NSObject
@property (nonatomic, copy) NSString *content;
@end
