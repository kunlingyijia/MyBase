//
//  HomePageCell2.m
//  DWduifubao
//
//  Created by 月美 刘 on 16/10/27.
//  Copyright © 2016年 bianming. All rights reserved.
//

#import "HomePageCell2.h"

@implementation HomePageCell2

- (void)awakeFromNib {
    [super awakeFromNib];
    
}
@end
