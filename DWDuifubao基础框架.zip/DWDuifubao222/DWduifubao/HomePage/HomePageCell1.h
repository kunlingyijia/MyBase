//
//  HomePageCell1.h
//  DWduifubao
//
//  Created by 月美 刘 on 16/10/26.
//  Copyright © 2016年 bianming. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface HomePageCell1 : UITableViewCell
@property (weak, nonatomic) IBOutlet UIButton *myPropertyBtn;       //"我的资产"的按钮
@property (weak, nonatomic) IBOutlet UIButton *dfSnatchGemBtn;      //"兑富夺宝"的按钮
@property (weak, nonatomic) IBOutlet UIButton *dfFinanceBtn;        //"兑富金融"的按钮
@property (weak, nonatomic) IBOutlet UIButton *O2OCollectMoneyBtn;  //"O2O收款"的按钮

- (IBAction)myPropertyBtnAction:(id)sender;       //"我的资产"的按钮事件
- (IBAction)dfSnatchGemBtnAction:(id)sender;      //"兑富夺宝"的按钮事件
- (IBAction)dfFinanceBtnAction:(id)sender;        //"兑富金融"的按钮事件
- (IBAction)O2OCollectMoneyBtnAction:(id)sender;  //"O2O收款"的按钮事件
@end
