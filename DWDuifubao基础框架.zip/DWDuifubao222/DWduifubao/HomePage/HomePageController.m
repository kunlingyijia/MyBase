//
//  HomePageController.m
//  DWduifubao
//
//  Created by 月美 刘 on 16/10/26.
//  Copyright © 2016年 bianming. All rights reserved.
//

#import "HomePageController.h"
#import "HomePageCell1.h"
#import "HomePageCell2.h"
#import "HomePageCell3.h"
#import "HomePageCell4.h"

@interface HomePageController ()<UITableViewDataSource, UITableViewDelegate>
@property (nonatomic, strong) UITableView *tableView;
@end

@implementation HomePageController
//视图即将出现时调用
- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    self.navigationController.navigationBar.hidden = YES;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, Width, Height) style:UITableViewStyleGrouped];
    self.tableView.backgroundColor = [UIColor colorWithHexString:kViewBackgroundColor];
    self.tableView.dataSource = self;
    self.tableView.delegate = self;
    
    //设置TableView自定义Cell的样式
    [self.tableView registerNib:[UINib nibWithNibName:@"HomePageCell1" bundle:[NSBundle mainBundle]] forCellReuseIdentifier:@"HomePageCell1"];
    [self.tableView registerNib:[UINib nibWithNibName:@"HomePageCell2" bundle:[NSBundle mainBundle]] forCellReuseIdentifier:@"HomePageCell2"];
    [self.tableView registerNib:[UINib nibWithNibName:@"HomePageCell3" bundle:[NSBundle mainBundle]] forCellReuseIdentifier:@"HomePageCell3"];
    [self.tableView registerNib:[UINib nibWithNibName:@"HomePageCell4" bundle:[NSBundle mainBundle]] forCellReuseIdentifier:@"HomePageCell4"];

    //设置tableViewCell之间的那条线隐藏掉
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    [self.view addSubview:self.tableView];
}

#pragma mark - UITableViewDataSource
//设置分区的个数
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 4;
}

//设置每个分区cell的个数
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 1;
}

//设置cell的样式
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    //"广告"
    if (indexPath.section == 0) {
        if (indexPath.row == 0) {
            HomePageCell1 *cell = [tableView dequeueReusableCellWithIdentifier:@"HomePageCell1" forIndexPath:indexPath];
            //设置点击cell不会变成灰色
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            return cell;
        }
    }
    //"热门活动"
    if (indexPath.section == 1) {
        if (indexPath.row == 0) {
            HomePageCell2 *cell = [tableView dequeueReusableCellWithIdentifier:@"HomePageCell2" forIndexPath:indexPath];
            //设置点击cell不会变成灰色
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            return cell;
        }
    }
    //"精选产品"
    if (indexPath.section == 2) {
        if (indexPath.row == 0) {
            HomePageCell3 *cell = [tableView dequeueReusableCellWithIdentifier:@"HomePageCell3" forIndexPath:indexPath];
            //设置点击cell不会变成灰色
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            return cell;
        }
    }
    //"精选店铺"
    if (indexPath.section == 3) {
        if (indexPath.row == 0) {
            HomePageCell4 *cell = [tableView dequeueReusableCellWithIdentifier:@"HomePageCell4" forIndexPath:indexPath];
            //设置点击cell不会变成灰色
            cell.selectionStyle = UITableViewCellSelectionStyleNone;
            return cell;
        }
    }
    
    HomePageCell2 *cell = [tableView dequeueReusableCellWithIdentifier:@"HomePageCell2" forIndexPath:indexPath];
    //设置点击tableViewCell不会变成灰色
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}

#pragma mark - UITableViewDelegate
//设置每个cell的高度
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    //"广告"
    if (indexPath.section == 0) {
        if (indexPath.row == 0) {
            return 230;
        }
    }
    //"热门活动"
    if (indexPath.section == 1) {
        if (indexPath.row == 0) {
            return 311;
        }
    }
    //"精选产品"
    if (indexPath.section == 2) {
        if (indexPath.row == 0) {
            return 451;
        }
    }
    //"精选店铺"
    if (indexPath.section == 3) {
        if (indexPath.row == 0) {
            return 287;
        }
    }
    return 20;
}

//设置每个分区分区头的高度
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return 0.01;
}

//设置每个分区分区脚的高度
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return 5;
}

//设置每个cell的点击事件
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [self showToast:@"敬请期待"];
}
@end
