//
//  HomePageCell1.m
//  DWduifubao
//
//  Created by 月美 刘 on 16/10/26.
//  Copyright © 2016年 bianming. All rights reserved.
//

#import "HomePageCell1.h"
#import "UIView+Toast.h"

@interface HomePageCell1 ()<UIScrollViewDelegate>
@property (nonatomic, strong) UIScrollView *scrollView;    //轮播器
@property (nonatomic, strong) UIPageControl *pageControl;  //页码
@property (nonatomic, strong) NSTimer *timer;              //定时器
@property (nonatomic, strong) NSMutableArray *imageArray;  //存放广告图片
@end

@implementation HomePageCell1

//懒加载
- (NSMutableArray *)imageArray {
    if (!_imageArray) {
        self.imageArray = [NSMutableArray arrayWithCapacity:0];
    }
    return _imageArray;
}

- (void)awakeFromNib {
    [super awakeFromNib];
    [self createView];
}

//创建视图
- (void)createView {
    //"首页广告"
    self.scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, Width, 160)];
    [self addSubview:self.scrollView];
    self.scrollView.delegate = self;
    UIImage *image1 = [UIImage imageNamed:@"首页-banner"];
    UIImage *image2 = [UIImage imageNamed:@"首页-banner"];
    UIImage *image3 = [UIImage imageNamed:@"首页-banner"];
    [self.imageArray addObject:image1];
    [self.imageArray addObject:image2];
    [self.imageArray addObject:image3];
    //设置scrollView显示内容大小
    self.scrollView.contentSize = CGSizeMake(self.imageArray.count * Width, 160);
    //设置scrollView是否显示水平方向的滚动条
    self.scrollView.showsHorizontalScrollIndicator = NO;
    //设置scrollView是否显示垂直方向的滚动条
    self.scrollView.showsVerticalScrollIndicator = NO;
    for(int i = 0;i < self.imageArray.count;i++)
    {
        UIImageView *imageView = [[UIImageView alloc] initWithImage:self.imageArray[i]];
        //图片显示形式
        imageView.contentMode = UIViewContentModeScaleAspectFill;
        //图片显示范围
        imageView.frame = CGRectMake(i*Width, 0, Width, 160);
        //加到scrollView中
        [self.scrollView addSubview:imageView];
    }
    //设置scrollView整页翻动
    self.scrollView.pagingEnabled = YES;
    
    //重构导航框的View
    UIView *headView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, Width, 44)];
    headView.backgroundColor = [UIColor clearColor];
    [self addSubview:headView];
    //设置"扫一扫"二维码的按钮样式
    UIButton *QRcodeBtn = [[UIButton alloc] initWithFrame:CGRectMake(10, 5, 34, 34)];
    [QRcodeBtn setImage:[UIImage imageNamed:@"首页-扫一扫图标"] forState:UIControlStateNormal];
    [headView addSubview:QRcodeBtn];
    //设置"信息"的按钮样式
    UIButton *messageBtn = [[UIButton alloc] init];
    [messageBtn setImage:[UIImage imageNamed:@"首页-信息图标"] forState:UIControlStateNormal];
    [headView addSubview:messageBtn];
    //自动布局
    [messageBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(headView).with.offset(-10);
        make.top.mas_equalTo(@(5));
        make.width.mas_equalTo(@(34));
        make.height.mas_equalTo(@(34));
    }];
    //设置"搜索框"的输入框的样式
    UITextField *searchTextField = [[UITextField alloc] init];
    [searchTextField setBackground:[UIImage imageNamed:@"首页-搜索框"]];
    searchTextField.placeholder = @"请输入关键字";
    searchTextField.font = [UIFont systemFontOfSize:kthirdTitleFont];
    searchTextField.textColor = [UIColor colorWithHexString:kTitleColor];
    [headView addSubview:searchTextField];
    //自动布局
    [searchTextField mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(QRcodeBtn.mas_right).with.offset(10);
        make.right.equalTo(messageBtn.mas_left).with.offset(-10);
        make.top.mas_equalTo(@(5));
        make.height.mas_equalTo(@(34));
    }];
    UIView *leftView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 10, 34)];
    searchTextField.leftView = leftView;
    //设置显示模式为永远显示(默认不显示)
    searchTextField.leftViewMode = UITextFieldViewModeAlways;
    UIView *rightView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, 34, 34)];
    searchTextField.rightView = rightView;
    UIButton *searchBtn = [[UIButton alloc] init];
    [searchBtn setImage:[UIImage imageNamed:@"首页-搜索框-搜索按钮"] forState:UIControlStateNormal];
    [searchTextField.rightView addSubview:searchBtn];
    searchTextField.rightViewMode = UITextFieldViewModeAlways;
    //自动布局
    [searchBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(rightView.mas_left);
        make.top.mas_equalTo(rightView.mas_top);
        make.width.mas_equalTo(@(34));
        make.height.mas_equalTo(@(34));
    }];
    //设置searchTextField不可编辑
    searchTextField.enabled = NO;
    
    //设置分页
    self.pageControl = [[UIPageControl alloc] initWithFrame:CGRectMake(0, 145, Width, 10)];
    //页面个数
    self.pageControl.numberOfPages = self.imageArray.count;
    //设置颜色
    self.pageControl.currentPageIndicatorTintColor = [UIColor redColor];
    self.pageControl.pageIndicatorTintColor = [UIColor colorWithHexString:kViewBackgroundColor];
    [self addSubview:self.pageControl];
    //开启定时器
    [self addTimer];
    
    //4个button:图在上,字在下,间隔0
    [self.myPropertyBtn setImagePosition:LXMImagePositionTop spacing:0];
    [self.dfSnatchGemBtn setImagePosition:LXMImagePositionTop spacing:0];
    [self.dfFinanceBtn setImagePosition:LXMImagePositionTop spacing:0];
    [self.O2OCollectMoneyBtn setImagePosition:LXMImagePositionTop spacing:0];
}


//添加定时器的事件
- (void)addTimer {
    self.timer = [NSTimer scheduledTimerWithTimeInterval:3.0f target:self selector:@selector(nextImage) userInfo:nil repeats:YES];
    [[NSRunLoop currentRunLoop] addTimer:self.timer forMode:NSRunLoopCommonModes];
}

//移除定时器的方法
- (void)removeTimer {
    [self.timer invalidate];
    self.timer = nil;
}

//定时器调用的方法
- (void)nextImage {
    int count = 3;  //图片的总数
    //增加pageControl的页码
    int page = 0;
    if (self.pageControl.currentPage == count - 1) {
        page = 0;
    }else {
        page = self.pageControl.currentPage + 1;
    }
    //计算scrollView滚动的位置
    CGFloat offsetX = page*Width;
    CGPoint offset = CGPointMake(offsetX, 0);
    [self.scrollView setContentOffset:offset animated:YES];
}

#pragma mark - UIScrollViewDelegate方法
//当scrollView正在滚动
- (void)scrollViewDidScroll:(UIScrollView *)scrollView {
    if (self.scrollView == scrollView) {
        //得到图片移动相对原点的坐标
        CGPoint point = scrollView.contentOffset;
        
        //移动不能超过左边;
        if(point.x < 0)
        {
            point.x = 0;
            scrollView.contentOffset = point;
        }
        //移动不能超过右边
        if(point.x > (self.imageArray.count-1)*Width)
        {
            point.x = Width*(self.imageArray.count-1);
            scrollView.contentOffset = point;
        }
        //移动不能超过上边
        if (point.y > 0) {
            point.y = 0;
            scrollView.contentOffset = point;
        }
        //移动不能超过下边
        if (point.y < self.scrollView.contentSize.height) {
            point.y = 0;
            scrollView.contentOffset = point;
        }
        
        //根据图片坐标判断页数
        NSInteger index = round(point.x/Width);
        self.pageControl.currentPage = index;
        
    }
}

//开始拖拽scrollView
- (void)scrollViewWillBeginDragging:(UIScrollView *)scrollView {
    //停止定时器(一旦停止,就不能再使用)
    [self removeTimer];
}

//停止拖拽scrollView
- (void)scrollViewDidEndDragging:(UIScrollView *)scrollView willDecelerate:(BOOL)decelerate {
    //开启定时器
    [self addTimer];
}

//"我的资产"的按钮事件
- (IBAction)myPropertyBtnAction:(id)sender {
    [self showToast:@"敬请期待"];
}

//"兑富夺宝"的按钮事件
- (IBAction)dfSnatchGemBtnAction:(id)sender {
    [self showToast:@"敬请期待"];
}

//"兑富金融"的按钮事件
- (IBAction)dfFinanceBtnAction:(id)sender {
    [self showToast:@"敬请期待"];
}

//"O2O收款"的按钮事件
- (IBAction)O2OCollectMoneyBtnAction:(id)sender {
    [self showToast:@"敬请期待"];
}

- (void)showToast:(NSString *)text{
    [self hideToastActivity];
    [self makeToast:text duration:1.5 position:CSToastPositionCenter];
}
@end
