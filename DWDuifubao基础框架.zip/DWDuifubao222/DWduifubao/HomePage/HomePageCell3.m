//
//  HomePageCell3.m
//  DWduifubao
//
//  Created by 月美 刘 on 16/10/27.
//  Copyright © 2016年 bianming. All rights reserved.
//

#import "HomePageCell3.h"

@implementation HomePageCell3

- (void)awakeFromNib {
    [super awakeFromNib];
    
}

@end
