//
//  PerfectDataController.m
//  DWduifubao
//
//  Created by 月美 刘 on 16/11/1.
//  Copyright © 2016年 bianming. All rights reserved.
//

#import "PerfectDataController.h"

@interface PerfectDataController ()

@end

@implementation PerfectDataController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self showBackBtn];
    self.title = @"完善资料";
    [self endEditingAction:self.view];
    self.contentSizeHeight.constant = 1130;
}

///上传"法人身份证正面"的按钮事件
- (IBAction)id_card_photoBtnAction:(id)sender {
}

///上传"法人身份证反面"的按钮事件
- (IBAction)id_card_back_photoBtnAction:(id)sender {
}

///上传"对公银行卡正面"的按钮事件
- (IBAction)bank_card_photoBtnAction:(id)sender {
}

///上传"营业执照"的按钮事件
- (IBAction)license_urlBtnAction:(id)sender {
}

///选择"开户行"的按钮事件
- (IBAction)chooseBankNameBtnAction:(id)sender {
}

///选择"所属行业"的按钮事件
- (IBAction)chooseTradeBtnAction:(id)sender {
}

///选择"地区"的按钮事件
- (IBAction)chooseAreaBtnAction:(id)sender {
}

///上传"logo图片"的按钮事件
- (IBAction)logoImageBtnAction:(id)sender {
}

///"提交"的按钮事件
- (IBAction)submitBtnAction:(id)sender {
}
@end
