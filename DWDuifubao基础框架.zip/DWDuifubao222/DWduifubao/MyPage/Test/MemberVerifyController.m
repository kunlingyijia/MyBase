//
//  MemberVerifyController.m
//  DWduifubao
//
//  Created by 月美 刘 on 16/10/31.
//  Copyright © 2016年 bianming. All rights reserved.
//

#import "MemberVerifyController.h"

@interface MemberVerifyController ()

@end

@implementation MemberVerifyController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self showBackBtn];
    self.title = @"会员认证";
    [self endEditingAction:self.view];
    
    self.contentSizeHeight.constant = Height-64;
    
}

///上传"身份证正面"的按钮事件
- (IBAction)id_card_photoBtnAction:(id)sender {
}

///上传"身份证反面"的按钮事件
- (IBAction)id_card_back_photoBtnAction:(id)sender {
}

///上传"银行卡正面"的按钮事件
- (IBAction)bank_card_photoBtnAction:(id)sender {
}

///上传"手持身份证＋银行卡"的按钮事件
- (IBAction)person_photoBtnAction:(id)sender {
}

///"提交审核"的按钮事件
- (IBAction)submitBtnAction:(id)sender {
}
@end
