//
//  IndianaCell.h
//  DWduifubao
//
//  Created by kkk on 16/9/12.
//  Copyright © 2016年 bianming. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface IndianaCell : UICollectionViewCell

@end
