//
//  IndianaKindListCell.h
//  DWduifubao
//
//  Created by kkk on 16/9/13.
//  Copyright © 2016年 bianming. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol  IndianaKindListCelldelegate <NSObject>

- (void)selectedJoin:(NSString *)goodsId;

@end

@interface IndianaKindListCell : UITableViewCell

@property (nonatomic, weak) id<IndianaKindListCelldelegate>delegate;

@end
