//
//  MyPageController.m
//  DWduifubao
//
//  Created by 月美 刘 on 16/9/12.
//  Copyright © 2016年 月美 刘. All rights reserved.
//

#import "MyPageController.h"
#import "BaseNavigationController.h"
#import "UIColor+DWColor.h"
#import "LoginController.h"
#import "IndianaViewController.h"
#import "SettingController.h"
#import "PersonalCenterController.h"

#import "ScoreRecordController.h"
#import "MemberVerifyController.h"
#import "PerfectDataController.h"

@interface MyPageController ()

@end

@implementation MyPageController
- (void)viewDidLoad {
    [super viewDidLoad];
    
    //设置可滑动的高度
    self.myPageContentSizeHeight.constant = 650;
    //设置导航框是否隐藏
    self.navigationController.navigationBar.hidden = YES;
    self.view.backgroundColor = [UIColor colorWithHexString:kViewBackgroundColor];

    [self addtargetAction];
}

//"设置"的按钮触发事件
- (IBAction)settingBtnAction:(id)sender {
    SettingController *settingController = [[SettingController alloc] init];
    [self.navigationController pushViewController:settingController animated:YES];
}

//"信息"的按钮触发事件
- (IBAction)messageBtnAction:(id)sender {
//    MemberVerifyController *memberVerifyController = [[MemberVerifyController alloc] initWithNibName:@"MemberVerifyController" bundle:nil];
//    [self.navigationController pushViewController:memberVerifyController animated:YES];
    PerfectDataController *perfectDataController = [[PerfectDataController alloc] initWithNibName:@"PerfectDataController" bundle:nil];
    [self.navigationController pushViewController:perfectDataController animated:YES];
}

//"个人中心"的按钮触发事件
- (IBAction)personalCenterBtnAction:(id)sender {
    PersonalCenterController *personalCenterController = [[PersonalCenterController alloc] init];
    [self.navigationController pushViewController:personalCenterController animated:YES];
}

//为View添加点击事件
- (void)addtargetAction {
    //"我的订单"
    UITapGestureRecognizer *myOrderViewTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(myOrderViewAction:)];
    [self.myOrderBgV addGestureRecognizer:myOrderViewTap];
    //"待付款"
    UITapGestureRecognizer *toPayViewTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(toPayViewAction:)];
    [self.toPayBgV addGestureRecognizer:toPayViewTap];
    //"待收货"
    UITapGestureRecognizer *toReceiveViewTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(toReceiveViewAction:)];
    [self.toReceiveBgV addGestureRecognizer:toReceiveViewTap];
    //"待评价"
    UITapGestureRecognizer *toEvaluateViewTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(toEvaluateViewAction:)];
    [self.toEvaluateBgV addGestureRecognizer:toEvaluateViewTap];
    //"已完成"
    UITapGestureRecognizer *hasCompletedViewTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(hasCompletedViewAction:)];
    [self.hasCompletedBgV addGestureRecognizer:hasCompletedViewTap];
    //"普通会员"
    UITapGestureRecognizer *generalMemberViewTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(generalMemberViewAction:)];
    [self.generalMemberBgV addGestureRecognizer:generalMemberViewTap];
    //"会员谱"
    UITapGestureRecognizer *memberChartViewTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(memberChartViewAction:)];
    [self.memberChartBgV addGestureRecognizer:memberChartViewTap];
    //"关注的商品"
    UITapGestureRecognizer *concernedMerchandiseViewTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(concernedMerchandiseViewAction:)];
    [self.concernedMerchandiseBgV addGestureRecognizer:concernedMerchandiseViewTap];
    //"关注的店铺"
    UITapGestureRecognizer *concernedStoreViewTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(concernedStoreViewAction:)];
    [self.concernedStoreBgV addGestureRecognizer:concernedStoreViewTap];
    //"我要供货"
    UITapGestureRecognizer *supplyOfMaterialViewTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(supplyOfMaterialViewAction:)];
    [self.supplyOfMaterialBgV addGestureRecognizer:supplyOfMaterialViewTap];
    //"我的代理"
    UITapGestureRecognizer *myAgentViewTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(myAgentViewAction:)];
    [self.myAgentBgV addGestureRecognizer:myAgentViewTap];
    //"O2O收款"
    UITapGestureRecognizer *O2OCollectMoneyViewTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(O2OCollectMoneyViewAction:)];
    [self.O2OCollectMoneyBgV addGestureRecognizer:O2OCollectMoneyViewTap];
    //"兑富夺宝"
    UITapGestureRecognizer *duifuSnatchGemViewTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(duifuSnatchGemViewAction:)];
    [self.duifuSnatchGemBgV addGestureRecognizer:duifuSnatchGemViewTap];
    //"兑富金融"
    UITapGestureRecognizer *duifuFinanceViewTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(duifuFinanceViewAction:)];
    [self.duifuFinanceBgV addGestureRecognizer:duifuFinanceViewTap];
    //"网贷一体机"
    UITapGestureRecognizer *P2BAllInOneViewTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(P2BAllInOneViewAction:)];
    [self.P2BAllInOneBgV addGestureRecognizer:P2BAllInOneViewTap];
}

//"我的订单"View事件
- (void)myOrderViewAction:(UITapGestureRecognizer *)sender {
}

//"待付款"View事件
- (void)toPayViewAction:(UITapGestureRecognizer *)sender {
}

//"待收货"View事件
- (void)toReceiveViewAction:(UITapGestureRecognizer *)sender {
}

//"待评价"View事件
- (void)toEvaluateViewAction:(UITapGestureRecognizer *)sender {
}

//"已完成"View事件
- (void)hasCompletedViewAction:(UITapGestureRecognizer *)sender {
}

//"普通会员"View事件
- (void)generalMemberViewAction:(UITapGestureRecognizer *)sender {
}

//"VIP会员"View事件
- (void)VIPMemberViewAction:(UITapGestureRecognizer *)sender {
}

//"创业会员"View事件
- (void)SYBMemberViewAction:(UITapGestureRecognizer *)sender {
}

//"会员谱"View事件
- (void)memberChartViewAction:(UITapGestureRecognizer *)sender {
}

//"关注的商品"View事件
- (void)concernedMerchandiseViewAction:(UITapGestureRecognizer *)sender {
}

//"关注的店铺"View事件
- (void)concernedStoreViewAction:(UITapGestureRecognizer *)sender {
}

//"我要供货"View事件
- (void)supplyOfMaterialViewAction:(UITapGestureRecognizer *)sender {
}

//"我的代理"View事件
- (void)myAgentViewAction:(UITapGestureRecognizer *)sender {
}

//"O2O收款"View事件
- (void)O2OCollectMoneyViewAction:(UITapGestureRecognizer *)sender {
}

//"兑富夺宝"View事件
- (void)duifuSnatchGemViewAction:(UITapGestureRecognizer *)sender {
    IndianaViewController *indianaC = [[IndianaViewController alloc] init];
    [self .navigationController pushViewController:indianaC animated:YES];
}

//"兑富金融"View事件
- (void)duifuFinanceViewAction:(UITapGestureRecognizer *)sender {
}

//"网贷一体机"View事件
- (void)P2BAllInOneViewAction:(UITapGestureRecognizer *)sender {
}

//“用户头像”的按钮触发事件
- (IBAction)userPhotoBtnAction:(id)sender {
    LoginController *loginController = [[LoginController alloc] initWithNibName:@"LoginController" bundle:nil];
    [self.navigationController pushViewController:loginController animated:YES];
}

#pragma mark - LifeCycle
- (void)viewWillAppear:(BOOL)animated {
    self.navigationController.navigationBar.hidden = YES;
}
- (void)viewWillDisappear:(BOOL)animated {
     self.navigationController.navigationBar.hidden = NO;
}

@end
