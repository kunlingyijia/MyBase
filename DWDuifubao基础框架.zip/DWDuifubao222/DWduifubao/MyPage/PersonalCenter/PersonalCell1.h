//
//  PersonalCell1.h
//  DWduifubao
//
//  Created by 月美 刘 on 16/10/11.
//  Copyright © 2016年 bianming. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PersonalCell1 : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *cellName;
@property (weak, nonatomic) IBOutlet UILabel *cellInfo;

@end
