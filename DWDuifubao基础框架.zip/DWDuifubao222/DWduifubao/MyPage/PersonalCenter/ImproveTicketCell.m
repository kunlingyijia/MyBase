//
//  ImproveTicketCell.m
//  DWduifubao
//
//  Created by 月美 刘 on 16/10/17.
//  Copyright © 2016年 bianming. All rights reserved.
//

#import "ImproveTicketCell.h"

@implementation ImproveTicketCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
