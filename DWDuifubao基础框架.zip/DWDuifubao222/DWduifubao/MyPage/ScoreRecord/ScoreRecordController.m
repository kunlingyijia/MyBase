//
//  ScoreRecordController.m
//  DWduifubao
//
//  Created by 月美 刘 on 16/10/26.
//  Copyright © 2016年 bianming. All rights reserved.
//

#import "ScoreRecordController.h"
#import "ScoreRecordCell.h"
#import "ScoreExchangeController.h"

@interface ScoreRecordController ()<UITableViewDataSource>
@property (nonatomic, strong) UITableView *tableView; //积分的列表
@end

@implementation ScoreRecordController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self showBackBtn];
    self.title = @"积分记录";
    
    //设置"兑换"的按钮样式
    UIButton *exchangeBtn = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 50, 30)];
    [exchangeBtn setTitle:@"兑换" forState:UIControlStateNormal];
    exchangeBtn.titleLabel.textAlignment = NSTextAlignmentRight;
    exchangeBtn.titleLabel.font = [UIFont systemFontOfSize:kthirdTitleFont];
    [exchangeBtn setTitleColor:[UIColor colorWithHexString:kRedColor] forState:UIControlStateNormal];
    [exchangeBtn addTarget:self action:@selector(exchangeBtnAction:) forControlEvents:UIControlEventTouchUpInside];
    self.navigationItem.rightBarButtonItem  = [[UIBarButtonItem alloc] initWithCustomView:exchangeBtn];
    
    //积分列表
    self.tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 90, Width, Height-154) style:UITableViewStylePlain];
    self.tableView.dataSource = self;
    //设置TableView自定义Cell的样式
    [self.tableView registerNib:[UINib nibWithNibName:@"ScoreRecordCell" bundle:[NSBundle mainBundle]] forCellReuseIdentifier:@"ScoreRecordCell"];
    //设置TableViewCell的高度
    self.tableView.rowHeight = 61;
    //设置tableViewCell之间的那条线隐藏掉
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.view addSubview:self.tableView];
}

//设置"兑换"的按钮事件
- (void)exchangeBtnAction:(UIButton *)button {
    ScoreExchangeController *scoreExchangeController = [[ScoreExchangeController alloc] initWithNibName:@"ScoreExchangeController" bundle:nil];
    [self.navigationController pushViewController:scoreExchangeController animated:YES];
}

#pragma mark - UITableViewDataSource
//设置cell的个数
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 15;
}

//设置cell的样式
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    ScoreRecordCell *cell = [tableView dequeueReusableCellWithIdentifier:@"ScoreRecordCell" forIndexPath:indexPath];
    //设置点击tableViewCell不会变成灰色
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
}
@end
