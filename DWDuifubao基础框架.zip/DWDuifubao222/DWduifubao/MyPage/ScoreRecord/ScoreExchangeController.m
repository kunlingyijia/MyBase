//
//  ScoreExchangeController.m
//  DWduifubao
//
//  Created by 月美 刘 on 16/10/26.
//  Copyright © 2016年 bianming. All rights reserved.
//

#import "ScoreExchangeController.h"
#import "ExchangeDFGlodController.h"
#import "ExchangeDFBaoController.h"

@interface ScoreExchangeController ()

@end

@implementation ScoreExchangeController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self showBackBtn];
    self.title = @"积分兑换";
    [self addViewTargetAction];
}

//为View添加点击事件
- (void)addViewTargetAction {
    //"兑换兑富金币"
    UITapGestureRecognizer *exchangeDFGlodViewTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(exchangeDFGlodViewAction:)];
    [self.exchangeDFGlodView addGestureRecognizer:exchangeDFGlodViewTap];
    //"兑换兑富金币+兑富宝"
    UITapGestureRecognizer *exchangeDFBaoViewTap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(exchangeDFBaoViewAction:)];
    [self.exchangeDFBaoView addGestureRecognizer:exchangeDFBaoViewTap];
}

//"兑换兑富金币"的View事件
- (void)exchangeDFGlodViewAction:(UITapGestureRecognizer *)sender {
    ExchangeDFGlodController *exchangeDFGlodController = [[ExchangeDFGlodController alloc] initWithNibName:@"ExchangeDFGlodController" bundle:nil];
    [self.navigationController pushViewController:exchangeDFGlodController animated:YES];
}

//"兑换兑富金币+兑富宝"的View事件
- (void)exchangeDFBaoViewAction:(UITapGestureRecognizer *)sender {
    ExchangeDFBaoController *exchangeDFBaoController = [[ExchangeDFBaoController alloc] initWithNibName:@"ExchangeDFBaoController" bundle:nil];
    [self.navigationController pushViewController:exchangeDFBaoController animated:YES];
}
@end
