//
//  RegisterController.h
//  DWduifubao
//
//  Created by 月美 刘 on 16/9/12.
//  Copyright © 2016年 月美 刘. All rights reserved.
//

#import "BaseViewController.h"

@interface RegisterController : BaseViewController

@property (weak, nonatomic) IBOutlet UITextField *phoneNumber;       //手机号
@property (weak, nonatomic) IBOutlet UITextField *verificationCode;  //验证码
@property (weak, nonatomic) IBOutlet UITextField *passwordText;      //密码
@property (weak, nonatomic) IBOutlet UIButton *eyeBtn;               //眼睛
@property (weak, nonatomic) IBOutlet UITextField *recommendCode;     //推荐码
@property (weak, nonatomic) IBOutlet UIButton *adressBtn;            //地区选择

- (IBAction)getVerificationCodeBtnAction:(id)sender;   //"获取验证码"的事件
- (IBAction)eyeBtnAction:(id)sender;                   //"眼睛"的事件
- (IBAction)selectAreaBtnAction:(id)sender;            //"地区选择"的事件
- (IBAction)registrationProtocolBtnAction:(id)sender;  //"注册协议"的事件
- (IBAction)registerBtnAction:(id)sender;              //"注册"的事件
- (IBAction)contactCustomerServiceBtnAction:(id)sender;//"联系客服"的事件
@end
